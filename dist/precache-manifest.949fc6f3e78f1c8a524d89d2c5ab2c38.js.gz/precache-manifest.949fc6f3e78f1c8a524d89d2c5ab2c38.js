self.__precacheManifest = [
  {
    "revision": "209a28ccda0e9c15065f",
    "url": "vendors~index~restaurant.bundle.js"
  },
  {
    "revision": "6fb650960e4aed86d390379d2cace35a",
    "url": "restaurant.html"
  },
  {
    "revision": "3d330539d7a284d54bf6",
    "url": "restaurant.bundle.js"
  },
  {
    "revision": "c2e0b871d4cf332466964ad3d7b6c73d",
    "url": "index.html"
  },
  {
    "revision": "92c956c86e557942bacb",
    "url": "index.bundle.js"
  }
];