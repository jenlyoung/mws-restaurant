self.__precacheManifest = [
  {
    "revision": "58c33046372703080da48578838f0458",
    "url": "restaurant.html"
  },
  {
    "revision": "0b4bea29edf4bcb301c7",
    "url": "restaurant.bundle.js"
  },
  {
    "revision": "7922e95788e356054a72c9cefa8b70ad",
    "url": "index.html"
  },
  {
    "revision": "c791b4037dcf95a366c5",
    "url": "index.bundle.js"
  }
];